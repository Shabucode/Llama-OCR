# Book Covers 2 > 2023-10-15 4:48pm
https://universe.roboflow.com/kernst/book-covers-2

Provided by a Roboflow user
License: CC BY 4.0

